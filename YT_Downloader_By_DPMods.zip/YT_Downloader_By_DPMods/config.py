# config.py

BOT_TOKEN = "YOUR_BOT_TOKEN"
FORCE_SUB_CHANNEL = "dp_mods"  # without '@'
ADMIN_USERNAME = "dpmods"
